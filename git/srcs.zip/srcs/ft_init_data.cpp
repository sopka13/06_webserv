/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_init_data.cpp                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: eyohn <sopka13@mail.ru>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/08/16 08:02:30 by eyohn             #+#    #+#             */
/*   Updated: 2021/09/09 10:47:28 by eyohn            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/headers.hpp"
#include <fcntl.h>

void		ft_init_data(t_vars *vars, int argc, char** argv, char** envp)
{
#ifdef DEBUG
	std::cout << "ft_init_data start" << std::endl;
#endif
	// step 0: Check errors in header
	if (WAIT_CLIENT_USEC > 1000000 || WAIT_CLIENT_SEC >= WAIT_REQUEST_FROM_CLIENT_SEC)
	{
		std::cout << "ERROR: timeouts in header have errors" << std::endl;
		ft_exit(vars);
	}

	// step 1: Clear struct
	ft_bzero(vars, sizeof(t_vars));
	exit_flag = false;

	// step 2: argc, argv, envp
	vars->argc = argc;
	vars->argv = argv;
	vars->envp = envp;

	// step 3: Allocate memory
	vars->servers = new std::deque<Server>;
	vars->sockets = new std::vector<Socket>;

	// step 4: Parse config file
	if (ft_parse_config(vars))
		ft_exit(vars);

	// step 5: Create semaphores for listen sockets
	sem_unlink(SEM_NAME_1);
	vars->sema = sem_open(SEM_NAME_1, 0100, 0666, vars->sockets->capacity());
	if (vars->sema == SEM_FAILED)
	{
		std::cout << "ERROR: Semaphore create faill" << std::endl;
		ft_exit(vars);
	}

#ifdef DEBUG
	std::cout << "ft_init_data end" << std::endl;
#endif
	return ;
}